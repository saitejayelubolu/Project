<?php
if(isset($_POST['submit'])=='submit'){
	//echo "yes";
	echo $id=$_POST['id'];
echo 	$name=$_POST['name'];
echo	$lname=$_POST['lname'];
	echo $mobile=$_POST['mobile'];
	$mysqli = new mysqli("localhost", "root", "", "lekkertuts");
	$in="INSERT INTO `search`(`id`, `name`, `lname`, `mobile`) VALUES('$id','$name','$lname',' $mobile')";
$sql = mysqli_query($mysqli,$in);
if($sql)
{
echo "data is inserted into database";	
}
else{
	echo "no";
}
}
else
{
	echo "no";
}
?>