<html>
<head>
<title>Search data</title>
</head>
<body>
<form method="POST" action="search.php" align="center">
<input type="text" id="search" name="search">
<input type="submit" name="submit" id="submit" value="submit">
</br>
</br>
<table border="2" align="center">
<tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Mobile</th></tr>
<?php
$mysqli = new mysqli("localhost", "root", "", "lekkertuts");
$sql = mysqli_query($mysqli, "SELECT * FROM search");//print_r($sql);
//exit;
 //$fetch = mysqli_num_rows($sql);
//$num=mysql_num_rows($select_query);
/*$fetch= mysqli_fetch_rows($sql);
while($fetch){
	echo "<tr><td>$fetch[id]</td><td>$fetch[name]</td><td>$fetch[lname]</td><td>$fetch[mobile]</td></tr>";
}
echo "no";*/
while ($row=mysqli_fetch_row($sql))
    {
    
	echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td></tr>";
    }
?>
</table>
</form>

</body>
</html>