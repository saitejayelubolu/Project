-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 19, 2018 at 06:52 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `calcium`
--

DROP TABLE IF EXISTS `calcium`;
CREATE TABLE IF NOT EXISTS `calcium` (
  `SNO` int(9) NOT NULL AUTO_INCREMENT,
  `Manufacturer_Name` varchar(255) NOT NULL,
  `Brand` varchar(255) NOT NULL,
  `Type` varchar(255) NOT NULL,
  `Package_Qty` varchar(255) NOT NULL,
  `Price` varchar(255) NOT NULL,
  `tablename` varchar(255) NOT NULL,
  PRIMARY KEY (`SNO`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `calcium`
--

INSERT INTO `calcium` (`SNO`, `Manufacturer_Name`, `Brand`, `Type`, `Package_Qty`, `Price`, `tablename`) VALUES
(1, 'Low Cost Standard Therapeutics (LOCOST)', 'Calcium Lactate (300 mg)', 'Tablet ', '1000 Tablet', '100', 'calcium'),
(2, 'Inspira (Svizera Healthcare) (Maneesh Pharmaceuticals Ltd)', 'Calcium Pantothenate (50 mg)', 'Tablet', '10 Tablet', '8.55', 'calcium'),
(3, 'Novartis Pharmaceuticals Ltd.', 'Calcium Sandoz (250 mg)', 'Tablet', '30 Tablet', '54', 'calcium'),
(4, 'Novartis Pharmaceuticals Ltd.', 'Calcium Sandoz (500 mg)', 'Tablet', '30 Tablet', '57.5', 'calcium'),
(5, 'Pharma Synth Formulations Ltd.', 'Calcium Resonium (15 mg)', 'Sachet', '1 Sachet', '96', 'calcium'),
(6, 'Jan Aushadhi', 'Calcium Citrate+Vit D3 (100 mg+125 iu) (Jan Aushadhi)', 'Syrup ', '550 ml', '30', 'calcium'),
(7, 'Novartis India Ltd', 'Calcium Sandoz (Inj)', 'Injection', '10 ml', '42', 'calcium'),
(8, 'Kokad Pharmaceutical Laboratories Ltd', 'Calcium Gluconate (10%) (Kokad Pharma)', 'Injection', '10 ml', '8', 'calcium'),
(9, 'Wyeth Pharmaceuticals Limited', 'Calcium Leucovorin (3 mg)', 'Injection', '1 ml', '14.8', 'calcium'),
(10, 'Biological Evans Ltd', 'Calcium Folinate (3 mg)', 'Injection', '1 ml', '22.85', 'calcium'),
(11, 'Biological Evans Ltd', 'Calcium Folinate Inj (3 mg)', 'Injection', '1 Vial', '29.7', 'calcium'),
(12, 'Biological Evans Ltd', 'Calcium Folinate (15 mg)', 'Injection', '2 ml', '74.3', 'calcium'),
(13, 'Wyeth Pharmaceuticals Limited', 'Calcium Leucovorin (30 mg)', 'Injection', '2 ml', '98', 'calcium'),
(14, 'Wyeth Pharmaceuticals Limited', 'Calcium Leucovorin (250 mg)', 'Injection', '5 ml', '275', 'calcium'),
(15, 'Shalina Laboratories Ltd', 'Calcium Gluconate inj (10%)', 'Injection', '10 ml', '79.8', 'calcium'),
(16, 'Biological Evans Ltd', 'Calcium Folinate Inj (15 mg)', 'Injection', '1 Vial', '108', 'calcium'),
(17, 'Biological Evans Ltd', 'Calcium Folinate (50 mg)', 'Injection', '1 Vial', '199.5', 'calcium');

-- --------------------------------------------------------

--
-- Table structure for table `cetirizine`
--

DROP TABLE IF EXISTS `cetirizine`;
CREATE TABLE IF NOT EXISTS `cetirizine` (
  `SNO` int(9) NOT NULL AUTO_INCREMENT,
  `Manufacturer_Name` varchar(255) NOT NULL,
  `Brand` varchar(255) NOT NULL,
  `Type` varchar(255) NOT NULL,
  `Package_Qty` varchar(255) NOT NULL,
  `Price` varchar(255) NOT NULL,
  `tablename` varchar(255) NOT NULL,
  PRIMARY KEY (`SNO`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cetirizine`
--

INSERT INTO `cetirizine` (`SNO`, `Manufacturer_Name`, `Brand`, `Type`, `Package_Qty`, `Price`, `tablename`) VALUES
(3, 'Swiss Medicare Pvt. Ltd.', 'Citizen DT (10 mg)', 'Tablet', '200-Tablets', '100', 'Cetirizine'),
(7, 'Samson Laboratories Pvt. Ltd.', 'Citriz (10 mg)', 'Tablet', '200-Tablets', '160', 'Cetirizine'),
(1, 'Jan Aushadhi', 'Cetirizine 10 mg (Jan Aushadhi)', 'Tablet', '10-Tablets', '2.5', 'Cetirizine'),
(2, 'Therawin Formulations', 'Alvin (10 mg)', 'Tablet', '10-Tablets', '4', 'Cetirizine'),
(12, 'Laborate Pharmaceuticals India Ltd.', 'Zin (10 mg)', 'Tablet', '500-Tablets', '475', 'Cetirizine'),
(4, 'Low Cost Standard Therapeutics (LOCOST)', 'Cetrizine (10 mg) (Low Cost)', 'Tablet', '10-Tablets', '6', 'Cetirizine'),
(5, 'Unison Pharmaceuticals', 'Dio 1 (10 mg)', 'Tablet', '10-Tablets', '6', 'Cetirizine'),
(6, 'Osho Pharma Pvt.Ltd.', 'Cetiminic (10 mg)', 'Tablet', '10-Tablets', '8', 'Cetirizine'),
(9, 'BRD Medilabs', 'Hisdin CT (10 mg)', 'Tablet', '10-Tablets', '9', 'Cetirizine'),
(10, 'Elegant Drugs Pvt. Ltd.', 'Ecitra (10 mg)', 'Tablet', '10-Tablets', '9', 'Cetirizine'),
(11, 'Reliance Formulation Pvt Ltd', 'Cettop (10 mg)', 'Tablet', '10-Tablets', '9.5', 'Cetirizine'),
(8, 'Shrinivas (Gujarat) Laboratories Pvt. Ltd', 'Acet (10 mg)', 'Tablet', '100-Tablets', '90', 'Cetirizine');

-- --------------------------------------------------------

--
-- Table structure for table `ciprofloxacin`
--

DROP TABLE IF EXISTS `ciprofloxacin`;
CREATE TABLE IF NOT EXISTS `ciprofloxacin` (
  `SNO` int(9) NOT NULL AUTO_INCREMENT,
  `Manufacturer_Name` varchar(255) NOT NULL,
  `Brand` varchar(255) NOT NULL,
  `Type` varchar(255) NOT NULL,
  `Package_Qty` varchar(255) NOT NULL,
  `Price` varchar(255) NOT NULL,
  `tablename` varchar(255) NOT NULL,
  PRIMARY KEY (`SNO`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ciprofloxacin`
--

INSERT INTO `ciprofloxacin` (`SNO`, `Manufacturer_Name`, `Brand`, `Type`, `Package_Qty`, `Price`, `tablename`) VALUES
(1, 'Acichem Laboratories', 'Ciprofloxacin (250 mg)', 'Tablet', '10-Tablets', '10', 'ciprofloxacin'),
(2, 'Modern Laboratories', 'Ciprofloxacin (250 mg) (Modern)', 'Tablet', '10-Tablets', '18', 'ciprofloxacin'),
(3, 'Cadila Pharmaceuticals Ltd.', 'Ciprofloxacin (250 mg) (Cadila Pharmaceuticals)', 'Tablet', '10-Tablets', '20', 'ciprofloxacin'),
(4, 'Smith Stanistreet Pharmaceuticals Ltd.', 'Ciprofloxacin (250 mg) (Smith)', 'Tablet', '10-Tablets', '28', 'ciprofloxacin'),
(5, 'Wings Pharmaceuticals (P) Ltd.', 'Ciprofloxacin (250 mg) (Wings)', 'Tablet', '10-Tablets', '31', 'ciprofloxacin'),
(6, 'INDCHEMIE HEALTH SPECIALITIES PVT. LTD.', 'NEWCIP TZH', 'Tablet', '10-Tablets', '33', 'ciprofloxacin'),
(7, 'MACMILLON PHARMACEUTICALS', 'CIPROMAC-TZ', 'Tablet', '10-Tablets', '35.46', 'ciprofloxacin'),
(8, 'EMCURE PHARMACEUTICALS LTD', 'CIPROBIOTIC-TN)', 'Tablet', '10-Tablets', '35.72', 'ciprofloxacin'),
(9, 'ALEMBIC LTD', 'STROX TZ(ALE)', 'Tablet', '10-Tablets', '35.97', 'ciprofloxacin'),
(10, 'SHREYA LIFE SCIENCES PVT. LTD', 'CEBECT TZ H', 'Tablet', '10-Tablets', '36.25', 'ciprofloxacin'),
(11, 'BIOLOGICAL E LTD', 'GASTROGYL', 'Tablet', '10-Tablets', '36.37', 'ciprofloxacin'),
(12, 'DR. REDDYS LABORATORIES LTD', 'CIPROLET AH', 'Tablet', '10-Tablets', '36.92', 'ciprofloxacin'),
(13, 'STANFORD LABORATORIES', 'DONNAGYL H', 'Tablet', '10-Tablets', '37', 'ciprofloxacin'),
(14, 'GENO PHARMACEUTICALS LTD', 'CIPTI', 'Tablet', '10-Tablets', '37.07', 'ciprofloxacin'),
(15, 'MANEESH PHARMACEUTICALS LTD', 'SIGMA CTH', 'Tablet', '10-Tablets', '39.3', 'ciprofloxacin'),
(16, 'ALEMBIC LTD', 'CIPROWIN TZ', 'Tablet', '10-Tablets', '39.4', 'ciprofloxacin'),
(17, 'SUN PHARMA LABORATORIES LTD.', 'FLOCY TZ', 'Tablet', '10-Tablets', '40', 'ciprofloxacin'),
(18, 'DIVINE LIFECARE PVT LTD', 'TICI', 'Tablet', '10-Tablets', '40', 'ciprofloxacin'),
(19, 'CIPLA LTD.', 'CIPLOX TZ H', 'Tablet', '10-Tablets', '59.87', 'ciprofloxacin'),
(20, 'RANBAXY LABORATORIES LTD', 'CIFRAN C TH', 'Tablet', '10-Tablets', '60.5', 'ciprofloxacin'),
(21, 'MAPRA LABORATORIES PVT. LTD', 'TINICIP', 'Tablet', '10-Tablets', '61.58', 'ciprofloxacin'),
(22, 'CENTAUR PHARMACEUTICALS PVT.LTD', 'CIPROTINI', 'Tablet', '10-Tablets', '63.87', 'ciprofloxacin'),
(23, 'GENO PHARMACEUTICALS LTD', 'CIPTI', 'Tablet', '10-Tablets', '72.71', 'ciprofloxacin'),
(24, 'MANEESH PHARMACEUTICALS LTD', 'SIGMA CT', 'Tablet', '10-Tablets', '77.1', 'ciprofloxacin'),
(25, 'ARISTO PHARMACEUTICALS PVT.LTD', 'MINI CITIZOL', 'Tablet', '10-Tablets', '102.62', 'ciprofloxacin'),
(26, 'CIPLA LTD.', 'CIPLOX TZ', 'Tablet', '10-Tablets', '106.54', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
