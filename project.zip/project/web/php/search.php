﻿<!DOCTYPE html>
<html>
<head>
    <title>Medicine Price List</title>
</head>
<body>
<!--start-home-->

<div class="main-header" id="house">
            <div class="header-strip">
               <div class="container">
                <p class="location"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> <a href="mailto:info@example.com">info@example.com</a></p>
                <p class="phonenum"><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> + 655 8858 54892</p>
                <div class="social-icons">
                    <ul>                    
                        <li><a href="#"><i class="facebook"> </i></a></li>
                        <li><a href="#"><i class="twitter"> </i></a></li>
                        <li><a href="#"><i class="google-plus"> </i></a></li>   
                        <li><a href="#"><i class="dribble"> </i></a></li>                                       
                    </ul>
                </div>
                <div class="clearfix"></div>
            </div>
            </div>
            <div class="header-middle">
              <div class="header-search">
               <form action="search.php" method="post">
                <div class="search">
                    <input type="search" placeholder="Search for Medicines and Health Products" name="Valuetosearch">
                </div>
                <div class="sear-sub">
                    <input type="submit" value=" " name="search">
                </div>



                <div class="clearfix"></div>
            </form>
        </div>
    </div>
                    
        <!--header-top-->
            <div class="header-top">
              <div class="container">
                     <nav class="navbar navbar-default">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                      </button>
                        <div class="logo">
                            <h1><a class="navbar-brand" href="index.html"><span>M</span>ed<span>G</span>ain  <img src="images/logo.png" alt=" " /></a></h1>
                        </div>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
                          <div class="top-menu">
                            <nav class="menu menu--francisco">
                                    <ul class="nav navbar-nav menu__list">
                                        <li class="menu__item menu__item--current"><a href="index.html" class="menu__link"><span class="menu__helper">Home</span></a></li>
                                        <li class="menu__item"><a href="about.html" class="menu__link"><span class="menu__helper">About Us</span></a></li>
                                        <li class="menu__item"><a href="typography.html" class="menu__link"><span class="menu__helper">Short Codes</span></a></li>
                                        <li class="menu__item"><a href="gallery.html" class="menu__link"><span class="menu__helper">Departments</span></a></li>
                                        <li class="menu__item"><a href="contact.html" class="menu__link"><span class="menu__helper">Contact Us</span></a></li>
                                    </ul>
                                </nav>
                            </div>
                    </div>
                    <!-- /.navbar-collapse -->
                </nav>

               <div class="clearfix"></div>
            </div>
    </div>





<?php
//set variables
$serverName='localhost';
$userName='root';
$password='';
$databaseName='mydatabase';

//create connection
$connection=mysqli_connect($serverName,$userName,$password,$databaseName);

//check connection 
            if(isset($_POST['search']))
            {
                $value = $_POST['Valuetosearch'];

           

            if ($value == 'ciprofloxacin' || $value == 'calcium' || $value == 'cetirizine')
            {
                    


                    $sql = "SELECT * FROM $value WHERE tablename='$value'";



                    
                        $result = mysqli_query($connection, $sql);                        
                       

                        echo"<table border='2' align='center'>";
                            echo "<tr><th>Manufacturer_Name</th><th>Brand</th><th>Type</th><th>Package_Qty</th><th>Price</th></tr>";
            
                            while($row = mysqli_fetch_array($result))
                            {
                                echo "<tr>";
                                echo "<td>" . $row['Manufacturer_Name'] . "</td>";
                                echo "<td>" . $row['Brand'] . "</td>";
                                echo "<td>" . $row['Type'] . "</td>";
                                echo "<td>" . $row['Package_Qty'] . "</td>";
                                echo "<td>" . $row['Price'] . "</td>";
                                echo "</tr>";
                            }
                        echo "</table>";
                }
                 else
                    {
                                                
                        echo "expected data is not found in data base";

                    }


    
            }
            else{
                echo "<span>NOTE: </span>enter the table name";

            }
            
          
?>













<!--/start-footer-section-->
            <div class="footer-section">
                <div class="container">
                    <div class="footer-grids wow bounceIn animated" data-wow-delay="0.4s">
                        <div class="col-md-3 footer-grid">
                        <h4>About <span>Medicinal</span></h4>
                        <div class="border2"></div>
                          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque id arcu neque, at convallis est felis.</p>
                          <p class="sub">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque id arcu neque, at convallis est felis.</p>
                        </div>
                        <div class="col-md-3 footer-grid tags">
                                <h4>The <span>Tags</span></h4>
                                <div class="border2"></div>
                            <ul class="tag">
                                <li><a href="#">Awesome</a></li>
                                <li><a href="#">Strategy</a></li>
                                <li><a href="#">Photography</a></li>
                                <li><a href="#">Development</a></li>
                                <li><a href="#">Css</a></li>
                                <li><a href="#">photoshop</a></li>
                                <li><a href="#">Html</a></li>
                                <li><a href="#">Awesome</a></li>
                                <li><a href="#">Strategy</a></li>
                                <li><a href="#">Photoshop</a></li>
                                <li><a href="#">Html</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 footer-grid tweet">
                                <h4>Latest <span>Tweets</span></h4>
                                <div class="border2"></div>
                                <div class="icon-3-square">
                                        <a href="#"><i class="square-3"></i></a>
                                    </div>
                            <div class="icon-text">
                                <p>I like this awesome freebie. Check it out By <a href="#"> Admin </a></p>
                                <h5>15 mins ago</h5>
                            </div>
                                <div class="clearfix"></div>
                                <div class="icon-3-square">
                                        <a href="#"><i class="square-3"></i></a>
                                </div>
                                <div class="icon-text">
                                    <p>I like this awesome freebie. Check it out  By <a href="#"> Admin </a> </p>
                                    <h5>15 mins ago</h5>
                                </div>
                                <div class="clearfix"></div>
                        </div>
                        <div class="col-md-3 footer-grid flickr">
                                <h4>Flickr <span>Feed </span></h4>
                                <div class="border2"></div>
                                <div class="flickr-grids">
                                        <div class="flickr-grid">
                                            <a href="#"><img src="images/t1.jpg" alt=" " title="CEO" /></a>
                                        </div>
                                        <div class="flickr-grid">
                                            <a href="#"><img src="images/t2.jpg" alt=" " title="GM" /></a>
                                        </div>
                                        <div class="flickr-grid">
                                            <a href="#"><img src="images/t3.jpg" alt=" " title="CEO" /></a>
                                        </div>
                                        <div class="clearfix"> </div>
                                        
                                        <div class="flickr-grid">
                                            <a href="#"><img src="images/t2.jpg" alt=" " title="GM" /></a>
                                        </div>
                                        <div class="flickr-grid">
                                            <a href="#"><img src="images/t3.jpg" alt=" " title="CEO" /></a>
                                        </div>
                                        <div class="flickr-grid">
                                            <a href="#"><img src="images/t1.jpg" alt=" " title="GM" /></a>
                                        </div>
                                <div class="clearfix"> </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
            </div>
        </div>
    <!--//end-footer-section-->
    <!--//footer-->
    <div class="footer-bottom">
        <div class="container">
            <p>© 2018 MedGain. All rights reserved | Design by <a href="http://github.com/saitejayelubolu">Sai Teja</a></p>
        </div>
    </div>
        <!--start-smooth-scrolling-->
                        <script type="text/javascript">
                                    $(document).ready(function() {
                                        /*
                                        var defaults = {
                                            containerID: 'toTop', // fading element id
                                            containerHoverID: 'toTopHover', // fading element hover id
                                            scrollSpeed: 1200,
                                            easingType: 'linear' 
                                        };
                                        */
                                        
                                        $().UItoTop({ easingType: 'easeOutQuart' });
                                        
                                    });
                                </script>
                                <!--end-smooth-scrolling-->
        <a href="#house" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
    <script src="js/bootstrap.js"></script>



</body>
</html>
